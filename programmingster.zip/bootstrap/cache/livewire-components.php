<?php return array (
  'post.show' => 'App\\Http\\Livewire\\Post\\Show',
);